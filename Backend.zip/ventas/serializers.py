from rest_framework import serializers
from django.utils import timezone
from datetime import timedelta

from .models import Proveedor, Venta, VentaDetalle
from productos.models import Producto


# =========================================================
#   PROVEEDOR
# =========================================================
class ProveedorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Proveedor
        fields = ["id", "nombre", "iniciales", "contacto", "telefono"]


# =========================================================
#   LIST SERIALIZER PERSONALIZADO PARA DETALLES
# =========================================================
class VentaDetalleListSerializer(serializers.ListSerializer):
    """
    Asegura que el contexto (incluyendo venta) se pase a cada ítem.
    """
    def to_internal_value(self, data):
        # propagamos contexto (request, view, etc.) al child
        self.child.context.update(self.context)
        return super().to_internal_value(data)


# =========================================================
#   DETALLE
# =========================================================
class VentaDetalleSerializer(serializers.ModelSerializer):
    producto_nombre = serializers.ReadOnlyField(source="producto.nombre")

    class Meta:
        model = VentaDetalle
        fields = [
            "id", "producto", "producto_nombre", "cantidad",
            "costo_unitario", "precio_unitario",
            "fecha_vencimiento", "credenciales", "comentario",
            "creado", "actualizado"
        ]
        read_only_fields = ["creado", "actualizado"]

    def validate(self, data):
        # DRF ya convierte el ID en instancia de Producto
        producto = data.get("producto")

        if not producto:
            raise serializers.ValidationError("Debes seleccionar un producto.")

        # venta SOLO si está en contexto (en create/update manual)
        venta = self.context.get("venta", None)

        # Precios automáticos (solo si tenemos venta en contexto)
        if venta and not data.get("precio_unitario"):
            data["precio_unitario"] = (
                producto.precio_distribuidor
                if venta.tipo_venta == "distribuidor"
                else producto.precio_cliente
            )

        if not data.get("costo_unitario"):
            # el costo no depende de la venta, lo podemos poner siempre
            data["costo_unitario"] = producto.costo_base

        # Fecha vencimiento automática
        if venta and not data.get("fecha_vencimiento"):
            base = venta.fecha_compra
        elif not data.get("fecha_vencimiento"):
            base = timezone.now().date()
        else:
            base = None

        if base is not None and not data.get("fecha_vencimiento"):
            data["fecha_vencimiento"] = base + timedelta(
                days=producto.duracion_dias or 30
            )

        return data


# =========================================================
#   VENTA
# =========================================================
class VentaSerializer(serializers.ModelSerializer):
    vendedor_nombre = serializers.ReadOnlyField(source="vendedor.username")
    cliente_nombre = serializers.ReadOnlyField(source="cliente.nombre", default=None)
    distribuidor_nombre = serializers.ReadOnlyField(source="distribuidor.nombre", default=None)
    proveedor_nombre = serializers.ReadOnlyField(source="proveedor.nombre")

    detalles = VentaDetalleSerializer(many=True)

    class Meta:
        model = Venta
        fields = [
            "id",
            "tipo_venta",
            "cliente", "cliente_nombre",
            "distribuidor", "distribuidor_nombre",
            "vendedor", "vendedor_nombre",
            "proveedor", "proveedor_nombre",
            "numero_pedido_proveedor", "numero_pedido",
            "fecha_compra",
            "estado_pago", "medio_pago", "es_garantia",
            "comentario",
            "total_costo",
            "total_precio",
            "descuento_porcentaje",
            "descuento_valor",
            "total_final",
            "detalles",
            "creado", "actualizado",
        ]
        read_only_fields = [
            "numero_pedido",
            "total_costo",
            "total_precio",
            "total_final",
            "creado", "actualizado",
        ]

    def to_internal_value(self, data):
        """
        Antes de validar, propagamos el contexto (request, view, etc.)
        hacia el child de 'detalles' para que lo tenga disponible.
        OJO: aquí TODAVÍA NO hay instancia de Venta.
        """
        if "detalles" in self.fields:
            self.fields["detalles"].child.context.update(self.context)
        return super().to_internal_value(data)

    def validate(self, data):
        tipo = data.get("tipo_venta") or getattr(self.instance, "tipo_venta", None)
        cliente = data.get("cliente") or getattr(self.instance, "cliente", None)
        distribuidor = data.get("distribuidor") or getattr(self.instance, "distribuidor", None)
        proveedor = data.get("proveedor") or getattr(self.instance, "proveedor", None)

        if tipo == "cliente" and not cliente:
            raise serializers.ValidationError("Para ventas a cliente final debes seleccionar un Cliente.")
        if tipo == "distribuidor" and not distribuidor:
            raise serializers.ValidationError("Para ventas a distribuidor debes seleccionar un Distribuidor.")
        if not proveedor:
            raise serializers.ValidationError("El proveedor es obligatorio.")

        return data

    def create(self, validated_data):
        detalles_data = validated_data.pop("detalles", [])

        # crear primero la venta (ya con descuentos)
        venta = Venta.objects.create(**validated_data)

        # ahora sí, para cada detalle pasamos venta en el contexto
        for d in detalles_data:
            serializer = VentaDetalleSerializer(
                data=d,
                context={"venta": venta},
            )
            serializer.is_valid(raise_exception=True)
            serializer.save(venta=venta)

        venta.recalcular_totales(commit=True)
        return venta

    def update(self, instance, validated_data):
        detalles_data = validated_data.pop("detalles", None)

        # actualizar campos de la venta
        for attr, val in validated_data.items():
            setattr(instance, attr, val)
        instance.save()

        # si llegan detalles, los reemplazamos
        if detalles_data is not None:
            instance.detalles.all().delete()
            for d in detalles_data:
                serializer = VentaDetalleSerializer(
                    data=d,
                    context={"venta": instance},
                )
                serializer.is_valid(raise_exception=True)
                serializer.save(venta=instance)

        instance.recalcular_totales(commit=True)
        return instance
