from rest_framework import viewsets, filters
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated

from .models import Proveedor, Venta, VentaDetalle
from .serializers import ProveedorSerializer, VentaSerializer, VentaDetalleSerializer
from core.permissions import IsAdminOrVendor


class ProveedorViewSet(viewsets.ModelViewSet):
    queryset = Proveedor.objects.all()
    serializer_class = ProveedorSerializer
    permission_classes = [IsAuthenticated, IsAdminOrVendor]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ["nombre", "iniciales", "contacto", "telefono"]
    ordering = ["nombre"]


class VentaViewSet(viewsets.ModelViewSet):
    serializer_class = VentaSerializer
    permission_classes = [IsAuthenticated, IsAdminOrVendor]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ["numero_pedido", "numero_pedido_proveedor", "comentario"]
    ordering = ["-creado"]

    def get_queryset(self):
        qs = Venta.objects.select_related(
            "vendedor", "cliente", "distribuidor", "proveedor"
        ).prefetch_related("detalles", "detalles__producto")

        user = self.request.user
        if user.rol == "admin":
            return qs
        if user.rol == "vendedor":
            return qs.filter(vendedor=user)
        return qs.none()

    def perform_create(self, serializer):
        user = self.request.user
        # Si es vendedor, fuerza vendedor = request.user
        if user.rol == "vendedor":
            serializer.save(vendedor=user)
        else:
            serializer.save()

    @action(detail=True, methods=["post"], url_path="recalcular")
    def recalcular(self, request, pk=None):
        venta = self.get_object()
        venta.recalcular_totales(commit=True)
        return Response({
            "ok": True,
            "total_costo": str(venta.total_costo),
            "total_precio": str(venta.total_precio)
        })

    @action(detail=True, methods=["get"], url_path="credenciales")
    def credenciales(self, request, pk=None):
        venta = self.get_object()
        detalles = venta.detalles.all()

        lista = []
        for d in detalles:
            for cred in (d.credenciales or []):
                lista.append({
                    "producto": d.producto.nombre,
                    "email": cred.get("email"),
                    "password": cred.get("password"),
                    "nota": cred.get("nota"),
                    "cuenta_completa": cred.get("cuenta_completa", False),
                    "fecha_vencimiento": d.fecha_vencimiento,
                })

        return Response({
            "venta": venta.id,
            "cliente": venta.cliente.usuario.username if venta.cliente else None,
            "distribuidor": venta.distribuidor.user.username if venta.distribuidor else None,
            "credenciales": lista
        })

class VentaDetalleViewSet(viewsets.ModelViewSet):
    serializer_class = VentaDetalleSerializer
    permission_classes = [IsAuthenticated, IsAdminOrVendor]

    def get_queryset(self):
        qs = VentaDetalle.objects.select_related("venta", "producto", "venta__vendedor")
        user = self.request.user
        if user.rol == "admin":
            return qs
        if user.rol == "vendedor":
            return qs.filter(venta__vendedor=user)
        return qs.none()

    def get_serializer_context(self):
        ctx = super().get_serializer_context()
        # Permite defaults dependientes de la venta
        venta_id = self.request.data.get("venta") or self.request.query_params.get("venta")
        if venta_id:
            try:
                ctx["venta"] = Venta.objects.get(pk=venta_id)
            except Venta.DoesNotExist:
                pass
        return ctx
