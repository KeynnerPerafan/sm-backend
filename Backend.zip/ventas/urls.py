from rest_framework.routers import DefaultRouter
from .views import ProveedorViewSet, VentaViewSet, VentaDetalleViewSet

router = DefaultRouter()
router.register(r'proveedores', ProveedorViewSet, basename='proveedor')
router.register(r'', VentaViewSet, basename='venta')
router.register(r'venta-detalles', VentaDetalleViewSet, basename='ventadetalle')

urlpatterns = router.urls
